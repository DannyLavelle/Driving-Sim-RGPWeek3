Driving simulator, get to the end a squick as possible
https://github.com/DannyLavelle/Driving-Sim-RGPWeek3

Steering wheel controls 
Right pedal - accelarate
Middle pedal - brake (if held once stop you start to reverse)
Steering wheel - turn
left paddle - switch from first to third person and vice versa
triangle - pause game


gamepad controls
right trigger - accelerate 
left trigger - brak
left stick - turn
start- pause 
button north - switch perspectives

keyboard

W/S - accelerate/brake
A/D - turn
ESC - pause
Tab - Switch perspectives

